export const NAMESPACE = 'simple-tree-table';
