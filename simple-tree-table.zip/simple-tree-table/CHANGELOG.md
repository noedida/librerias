# CHANGELOG

## 0.4.0

* Separate store class and change store options.
* Destroy existing instance on initialization.
* Tweak css.

## 0.3.3

* Allow icon in the descendant element.

## 0.3.2

* Unbind existing events before bind.

## 0.3.1

* Add class name for root node.

## 0.3.0

* Add icon position option.

## 0.2.0

* Simplify icon class.
* Use event trigger for callbacks.
* Introduce opened option instead of collapsed option.
* Export class for convenience.
* Refactoring.

## 0.1.0

* First release.
